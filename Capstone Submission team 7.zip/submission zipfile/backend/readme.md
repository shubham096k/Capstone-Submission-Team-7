After cloning the project from github, move to the directory of manage.py and run the following commands:

Steps to set up and run the Python project:

1. Create a virtual environment
   python -m venv venv

2. Activate the virtual environment
   On Windows: venv\Scripts\activate
   On macOS/Linux: source venv/bin/activate

3. Install project dependencies
   pip install -r requirements.txt

4. Run database migrations
   python manage.py makemigrations
   python manage.py migrate

5. Start the development server
   python manage.py runserver

By default, the server will run at: http://127.0.0.1:8000/

6. For running the tests, use this command in the terminal,make sure you are in the same dir as pytest.ini: 
   pytest


Project Structure:

virtual-study-group-backend/
├── venv/
├── manage.py
├── requirements.txt
├── vsg_project/
│ ├── init.py
│ ├── asgi.py
│ ├── settings.py
│ ├── urls.py
│ └── wsgi.py
├── core/
│ ├── init.py
│ ├── admin.py
│ ├── apps.py
│ ├── models.py
│ ├── serializers.py
│ ├── urls.py
│ ├── views.py
│ ├── permissions.py
│ ├── tests.py
│ ├── exceptions.py
│ └── migrations/
├── media/
└── .gitignore


API Endpoint Reference:

Register User
Method: POST
Endpoint: /api/auth/register/
Headers: Content-Type: application/json
Purpose: Create a new user account.

Login User
Method: POST
Endpoint: /api/auth/login/
Headers: Content-Type: application/json
Purpose: Log in a user and get JWT tokens.

Refresh Token
Method: POST
Endpoint: /api/auth/refresh/
Headers: Content-Type: application/json
Purpose: Generate a new access token using a refresh token.

Get User Profile
Method: GET
Endpoint: /api/profile/
Headers: Authorization: Bearer <access_token>
Purpose: Fetch profile details of the logged-in user.

Update User Profile
Method: PUT
Endpoint: /api/profile/
Headers: Authorization: Bearer <access_token>, Content-Type: application/json
Purpose: Update profile settings such as theme or bio.

Create Group
Method: POST
Endpoint: /api/groups/
Headers: Authorization: Bearer <access_token>, Content-Type: application/json
Purpose: Create a new study group.

Get Discover Groups
Method: GET
Endpoint: /api/groups/
Headers: Authorization: Bearer <access_token>
Purpose: Get groups the user has not joined yet.

Get My Groups
Method: GET
Endpoint: /api/groups/my-groups/
Headers: Authorization: Bearer <access_token>
Purpose: Get all groups the user is a member of.

Get My Admin Groups
Method: GET
Endpoint: /api/groups/my-admin-groups/
Headers: Authorization: Bearer <access_token>
Purpose: Get groups the user administers.

Join Group
Method: POST
Endpoint: /api/groups/<id>/join/
Headers: Authorization: Bearer <access_token>
Purpose: Join a specific group.

Leave Group
Method: POST
Endpoint: /api/groups/<id>/leave/
Headers: Authorization: Bearer <access_token>
Purpose: Leave a specific group.

List All Sessions
Method: GET
Endpoint: /api/sessions/
Headers: Authorization: Bearer <access_token>
Purpose: View all sessions from groups the user belongs to.

List Sessions by Group
Method: GET
Endpoint: /api/sessions/?group=<id>
Headers: Authorization: Bearer <access_token>
Purpose: View sessions for a specific group.

Filter Sessions by Status
Method: GET
Endpoint: /api/sessions/?status=<active|completed>
Headers: Authorization: Bearer <access_token>
Purpose: View active or completed sessions.

Create Session
Method: POST
Endpoint: /api/sessions/
Headers: Authorization: Bearer <access_token>, Content-Type: application/json
Purpose: Create a study session for a group.

Session Details
Method: GET
Endpoint: /api/sessions/<id>/
Headers: Authorization: Bearer <access_token>
Purpose: View details of a specific session.

Delete Session
Method: DELETE
Endpoint: /api/sessions/<id>/
Headers: Authorization: Bearer <access_token>
Purpose: Delete a session (admin only).

List Tasks
Method: GET
Endpoint: /api/tasks/
Headers: Authorization: Bearer <access_token>
Purpose: View tasks accessible to the user.

List Tasks by Session
Method: GET
Endpoint: /api/tasks/?session=<id>
Headers: Authorization: Bearer <access_token>
Purpose: View tasks for a specific session.

Create Task
Method: POST
Endpoint: /api/tasks/
Headers: Authorization: Bearer <access_token>, Content-Type: application/json
Purpose: Create a new task for a session.

Update Task
Method: PATCH
Endpoint: /api/tasks/<id>/
Headers: Authorization: Bearer <access_token>, Content-Type: application/json
Purpose: Update an existing task.

Delete Task
Method: DELETE
Endpoint: /api/tasks/<id>/
Headers: Authorization: Bearer <access_token>
Purpose: Delete a task (creator or admin).

List Documents
Method: GET
Endpoint: /api/documents/
Headers: Authorization: Bearer <access_token>
Purpose: List visible documents belonging to groups the user is part of.

Upload Document
Method: POST
Endpoint: /api/documents/
Headers: Authorization: Bearer <access_token>, Content-Type: multipart/form-data
Purpose: Upload a document to a group.

Approve Document
Method: POST
Endpoint: /api/documents/<id>/approve/
Headers: Authorization: Bearer <access_token>
Purpose: Approve a pending document (admin only).

Delete Document
Method: DELETE
Endpoint: /api/documents/<id>/
Headers: Authorization: Bearer <access_token>
Purpose: Delete a document (admin only).

List Document Comments
Method: GET
Endpoint: /api/document-comments/
Headers: Authorization: Bearer <access_token>
Purpose: Fetch comments for documents in the user's groups.

List Comments for Specific Document
Method: GET
Endpoint: /api/document-comments/?document=<id>
Headers: Authorization: Bearer <access_token>
Purpose: Fetch comments for a specific document.

Create Comment
Method: POST
Endpoint: /api/document-comments/
Headers: Authorization: Bearer <access_token>, Content-Type: application/json
Purpose: Add a comment to a document.

Delete Comment
Method: DELETE
Endpoint: /api/document-comments/<id>/
Headers: Authorization: Bearer <access_token>
Purpose: Delete a comment (creator or group admin).