import pytest
from rest_framework.test import APIClient
from django.urls import reverse
from django.contrib.auth.models import User
pytestmark = pytest.mark.django_db


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def create_user():
    def _create(username, email, password):
        return User.objects.create_user(username=username, email=email, password=password)
    return _create


# ------------------------------------------------------------
# 1. REGISTER USER
# ------------------------------------------------------------
def test_register_user(client):
    payload = {
        "username": "shubham",
        "email": "shubham@example.com",
        "password": "StrongPassword123"
    }

    response = client.post("/api/auth/register/", payload, format="json")
    print(response.status_code, response.data)

    assert response.status_code == 201
    assert response.data["username"] == "shubham"
    assert response.data["email"] == "shubham@example.com"


# ------------------------------------------------------------
# 2. LOGIN USER
# ------------------------------------------------------------
def test_login_user(client, create_user):
    create_user("shubham", "shubham@example.com", "StrongPassword123")

    payload = {
        "username": "shubham",
        "password": "StrongPassword123"
    }

    response = client.post("/api/auth/login/", payload, format="json")

    assert response.status_code == 200
    assert "access" in response.data
    assert "refresh" in response.data


# ------------------------------------------------------------
# 3. REFRESH TOKEN
# ------------------------------------------------------------
def test_refresh_token(client, create_user):
    user = create_user("shubham2", "s@g.com", "StrongPassword123")

    login_res = client.post("/api/auth/login/", {
        "username": "shubham2",
        "password": "StrongPassword123"
    }, format="json")

    refresh = login_res.data["refresh"]

    response = client.post("/api/auth/refresh/",
                           {"refresh": refresh}, format="json")

    assert response.status_code == 200
    assert "access" in response.data


# ------------------------------------------------------------
# 4. GET PROFILE
# ------------------------------------------------------------
def test_get_profile(client, create_user):
    create_user("john", "john@example.com", "StrongPassword123")

    login = client.post("/api/auth/login/", {
        "username": "john",
        "password": "StrongPassword123"
    }, format="json")

    token = login.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)
    response = client.get("/api/profile/")

    assert response.status_code == 200
    assert "user_id" in response.data
    assert "username" in response.data
    assert "theme_mode" in response.data


# ------------------------------------------------------------
# 5. UPDATE PROFILE
# ------------------------------------------------------------
def test_update_profile(client, create_user):
    create_user("john2", "john2@example.com", "StrongPassword123")

    login = client.post("/api/auth/login/", {
        "username": "john2",
        "password": "StrongPassword123"
    }, format="json")

    token = login.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    payload = {
        "theme_mode": "dark",
        "bio": "I am a developer"
    }

    response = client.put("/api/profile/", payload, format="json")

    assert response.status_code == 200
    assert response.data["theme_mode"] == "dark"
    assert response.data["bio"] == "I am a developer"


# ------------------------------------------------------------
# GROUP ENDPOINTS
# ------------------------------------------------------------

# 6. CREATE GROUP
def test_create_group(client, create_user):
    create_user("admin", "admin@example.com", "pass12345")
    login = client.post(
        "/api/auth/login/", {"username": "admin", "password": "pass12345"}, format="json")
    token = login.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    payload = {
        "name": "Python Study Group",
        "description": "Learn Django and REST APIs together"
    }

    response = client.post("/api/groups/", payload, format="json")

    assert response.status_code == 201
    assert response.data["name"] == "Python Study Group"


# 7. GET /api/groups/
def test_get_discover_groups(client, create_user):
    user = create_user("u1", "u1@x.com", "pass1234")

    login = client.post(
        "/api/auth/login/", {"username": "u1", "password": "pass1234"}, format="json")
    token = login.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    response = client.get("/api/groups/")

    assert response.status_code == 200
    assert isinstance(response.data, list)


# 8. GET MY GROUPS
def test_get_my_groups(client, create_user):
    user = create_user("u2", "u2@x.com", "pass1234")

    login = client.post(
        "/api/auth/login/", {"username": "u2", "password": "pass1234"}, format="json")
    token = login.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    response = client.get("/api/groups/my-groups/")

    assert response.status_code == 200
    assert isinstance(response.data, list)


# 9. GET MY ADMIN GROUPS
def test_get_my_admin_groups(client, create_user):
    user = create_user("u3", "u3@x.com", "pass1234")

    login = client.post(
        "/api/auth/login/", {"username": "u3", "password": "pass1234"}, format="json")
    token = login.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    response = client.get("/api/groups/my-admin-groups/")

    assert response.status_code == 200
    assert isinstance(response.data, list)


# ------------------------------------------------------------
# 10. JOIN GROUP
# ------------------------------------------------------------
def test_join_group(client, create_user):
    admin = create_user("owner", "o@x.com", "pass12345")

    login_admin = client.post(
        "/api/auth/login/", {"username": "owner", "password": "pass12345"}, format="json")
    admin_token = login_admin.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + admin_token)
    group = client.post(
        "/api/groups/", {"name": "GroupA", "description": "Test"}, format="json")

    member = create_user("member", "m@x.com", "pass12345")
    login_member = client.post(
        "/api/auth/login/", {"username": "member", "password": "pass12345"}, format="json")
    member_token = login_member.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + member_token)
    response = client.post(f"/api/groups/{group.data['id']}/join/")

    assert response.status_code == 201


# ------------------------------------------------------------
# 11. LEAVE GROUP
# ------------------------------------------------------------
def test_leave_group(client, create_user):
    owner = create_user("owner2", "own2@x.com", "pass12345")

    login_owner = client.post(
        "/api/auth/login/", {"username": "owner2", "password": "pass12345"}, format="json")
    owner_token = login_owner.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + owner_token)
    group = client.post(
        "/api/groups/", {"name": "GroupB", "description": "Test"}, format="json")

    member = create_user("member2", "m2@x.com", "pass12345")
    login_member = client.post(
        "/api/auth/login/", {"username": "member2", "password": "pass12345"}, format="json")
    member_token = login_member.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + member_token)
    client.post(f"/api/groups/{group.data['id']}/join/")

    response = client.post(f"/api/groups/{group.data['id']}/leave/")

    assert response.status_code == 200


# ------------------------------------------------------------
# SESSION ENDPOINT TESTS
# ------------------------------------------------------------

# 12. LIST SESSIONS
def test_list_sessions(client, create_user):
    user = create_user("ss1", "ss1@x.com", "pass123")
    login = client.post(
        "/api/auth/login/", {"username": "ss1", "password": "pass123"}, format="json")

    token = login.data["access"]
    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    response = client.get("/api/sessions/")

    assert response.status_code == 200


# 13. SESSIONS BY GROUP
def test_sessions_by_group(client, create_user):
    user = create_user("ss2", "ss2@x.com", "pass123")
    login = client.post(
        "/api/auth/login/", {"username": "ss2", "password": "pass123"}, format="json")

    token = login.data["access"]
    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    response = client.get("/api/sessions/?group=1")
    assert response.status_code == 200


# 14. FILTER BY STATUS
def test_filter_sessions_status(client, create_user):
    user = create_user("ss3", "ss3@x.com", "pass123")
    login = client.post(
        "/api/auth/login/", {"username": "ss3", "password": "pass123"}, format="json")

    token = login.data["access"]
    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    response = client.get("/api/sessions/?status=active")

    assert response.status_code == 200


# 15. CREATE SESSION
def test_create_session(client, create_user):
    admin = create_user("ssadmin", "ssa@x.com", "pass123")
    login_admin = client.post(
        "/api/auth/login/", {"username": "ssadmin", "password": "pass123"}, format="json")
    admin_token = login_admin.data["access"]

    client.credentials(HTTP_AUTHORIZATION="Bearer " + admin_token)
    group_res = client.post(
        "/api/groups/", {"name": "SessionGroup", "description": "Test"}, format="json")
    group_id = group_res.data["id"]

    payload = {
        "group": group_id,
        "title": "React Study Session",
        "description": "Hooks and effects",
        "start_time": "2025-11-10T15:00:00Z",
        "end_time": "2025-11-10T17:00:00Z"
    }

    response = client.post("/api/sessions/", payload, format="json")

    assert response.status_code == 201


# 16. SESSION DETAILS
def test_session_details(client, create_user):
    admin = create_user("ssadmin2", "ssa2@x.com", "pass123")
    login_admin = client.post(
        "/api/auth/login/", {"username": "ssadmin2", "password": "pass123"}, format="json")
    token = login_admin.data["access"]
    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    group = client.post(
        "/api/groups/", {"name": "G", "description": "D"}, format="json")
    group_id = group.data["id"]

    session = client.post("/api/sessions/", {
        "group": group_id,
        "title": "React Session",
        "description": "Learn hooks",
        "start_time": "2025-11-10T15:00:00Z",
        "end_time": "2025-11-10T17:00:00Z"
    }, format="json")

    session_id = session.data["id"]

    response = client.get(f"/api/sessions/{session_id}/")

    assert response.status_code == 200
    assert response.data["id"] == session_id


# 17. DELETE SESSION
def test_delete_session(client, create_user):
    admin = create_user("admin_session", "as@x.com", "pass123")
    login_admin = client.post(
        "/api/auth/login/", {"username": "admin_session", "password": "pass123"}, format="json")
    token = login_admin.data["access"]
    client.credentials(HTTP_AUTHORIZATION="Bearer " + token)

    group = client.post(
        "/api/groups/", {"name": "DelG", "description": "D"}, format="json")
    group_id = group.data["id"]

    session = client.post("/api/sessions/", {
        "group": group_id,
        "title": "Delete Session",
        "description": "to be deleted",
        "start_time": "2025-11-10T15:00:00Z",
        "end_time": "2025-11-10T17:00:00Z"
    }, format="json")

    session_id = session.data["id"]

    response = client.delete(f"/api/sessions/{session_id}/")

    assert response.status_code == 204
